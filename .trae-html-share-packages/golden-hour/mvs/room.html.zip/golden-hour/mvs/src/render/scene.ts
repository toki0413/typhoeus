import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { FLOOR_H } from './constants';
import { concreteTexture } from './textures';
export { FLOOR_H };

export const CAMERA_FRUSTUM = 10;

export function buildStaticGeometry(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];

  const addBox = (w: number, h: number, d: number, x: number, y: number, z: number) => {
    const g = new THREE.BoxGeometry(w, h, d);
    g.translate(x, y, z);
    parts.push(g);
  };

  for (let f = 0; f < 2; f++) {
    const base = f * FLOOR_H;
    // 楼板只保留后半段，前缘剖开，正交相机才能看到每层
    addBox(26, 0.3, 8, 0, base, -3);
    addBox(26, FLOOR_H, 0.3, 0, base + FLOOR_H / 2, -7);
    addBox(0.3, FLOOR_H, 14, -13, base + FLOOR_H / 2, 0);
    addBox(0.3, FLOOR_H, 14, 13, base + FLOOR_H / 2, 0);
    for (let x = -13; x <= 13; x += 6.5) {
      addBox(0.28, FLOOR_H, 0.28, x, base + FLOOR_H / 2, 7);
    }
  }

  return mergeGeometries(parts, false)!;
}

export function createScene(): {
  scene: THREE.Scene;
  camera: THREE.OrthographicCamera;
  renderer: THREE.WebGLRenderer;
  heroLights: { key: THREE.PointLight; rim: THREE.PointLight };
} {
  const lowPower =
    typeof navigator !== 'undefined' && (navigator.hardwareConcurrency ?? 8) <= 4;

  const buildRenderer = (antialias: boolean): THREE.WebGLRenderer =>
    new THREE.WebGLRenderer({ antialias, powerPreference: 'high-performance' });

  let renderer = buildRenderer(true);
  let gl = renderer.getContext();
  let debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
  let gpuName = debugInfo ? String(gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)) : '';
  const softwareGL = /swiftshader|llvmpipe|software|basic render/i.test(gpuName);
  // SwiftShader pays dearly for MSAA; drop it there and keep the frame alive.
  if (softwareGL) {
    renderer.dispose();
    renderer = buildRenderer(false);
    gl = renderer.getContext();
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPower ? 1.25 : 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.3;
  renderer.shadowMap.enabled = !lowPower && !softwareGL;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0b0e12);
  scene.fog = new THREE.FogExp2(0x0b0e12, 0.011);

  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 300);
  const frustum = CAMERA_FRUSTUM;
  const aspect = window.innerWidth / window.innerHeight;
  camera.left = -frustum * aspect;
  camera.right = frustum * aspect;
  camera.top = frustum;
  camera.bottom = -frustum;
  camera.position.set(28, 24, 28);
  camera.lookAt(0, 3, 0);
  camera.updateProjectionMatrix();

  scene.add(new THREE.HemisphereLight(0x9db3cc, 0x1a2028, 1.0));
  scene.add(new THREE.AmbientLight(0x2b3440, 0.45));

  // IBL keeps the authored PBR gear (leather, steel, reflective tape) readable.
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTexture = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTexture;
  scene.environmentIntensity = 0.24;
  pmrem.dispose();

  const key = new THREE.DirectionalLight(0xffc894, 3.1);
  key.position.set(18, 30, 12);
  if (!lowPower) {
    key.castShadow = true;
    const shadowSize = softwareGL ? 1024 : 2048;
    key.shadow.mapSize.set(shadowSize, shadowSize);
    key.shadow.camera.left = -18;
    key.shadow.camera.right = 18;
    key.shadow.camera.top = 16;
    key.shadow.camera.bottom = -16;
    key.shadow.camera.near = 1;
    key.shadow.camera.far = 80;
    key.shadow.bias = -0.0006;
  }
  scene.add(key);

  const fill = new THREE.DirectionalLight(0x6f8fb5, 1.05);
  fill.position.set(-20, 16, -10);
  scene.add(fill);

  const wallMap = concreteTexture();
  const building = new THREE.Mesh(
    buildStaticGeometry(),
    new THREE.MeshStandardMaterial({
      color: wallMap ? 0xffffff : 0x59626d,
      map: wallMap ?? undefined,
      roughness: 0.92,
      metalness: 0.03,
    })
  );
  building.castShadow = true;
  building.receiveShadow = true;
  scene.add(building);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(200, 200),
    new THREE.MeshStandardMaterial({ color: 0x12161b, roughness: 1 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.16;
  ground.receiveShadow = true;
  scene.add(ground);

  // Door work light (set dressing) plus two hero lights that fade in with the
  // camera push, staged around the 202 landing.
  const doorGlow = new THREE.PointLight(0xffc27a, 2.2, 4.5, 2);
  doorGlow.position.set(-0.7, 4.85, 2.15);
  scene.add(doorGlow);

  const heroKey = new THREE.PointLight(0xffd6ad, 0, 6.5, 2);
  heroKey.position.set(1.9, 5.4, 2.9);
  scene.add(heroKey);

  const heroRim = new THREE.PointLight(0x8ab7ff, 0, 6.0, 2);
  heroRim.position.set(-2.6, 5.0, -0.4);
  scene.add(heroRim);

  return { scene, camera, renderer, heroLights: { key: heroKey, rim: heroRim } };
}
