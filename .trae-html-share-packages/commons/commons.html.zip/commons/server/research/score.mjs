/**
 * 服务端复核的核心纯函数：确定性种子 + 前向模拟 + 结构签名评分。
 * 抽出来是为了能被测试直接调用，避免评分逻辑藏在 HTTP 入口里。
 */

import { ReactionDiffusionEngine, normalizeField } from '../../src/scientific.js';
import { structuralSignature, signatureDistance } from './signature.mjs';
import { hashString, mulberry32 } from '../../src/rng.js';

function clamp(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/* 没带种子时，用配方 id 派生一个确定性的 4 核种子，保证服务端复核可复现 */
export function deterministicMask(seedStr, w = 64, h = 64) {
  const mask = new Uint8Array(w * h);
  const rand = mulberry32(hashString(seedStr || 'commons'));
  for (let d = 0; d < 4; d++) {
    const cx = 8 + Math.floor(rand() * (w - 16));
    const cy = 8 + Math.floor(rand() * (h - 16));
    const r = 4 + Math.floor(rand() * 3);
    for (let y = Math.max(0, cy - r); y <= Math.min(h - 1, cy + r); y++) {
      for (let x = Math.max(0, cx - r); x <= Math.min(w - 1, cx + r); x++) {
        if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) mask[y * w + x] = 255;
      }
    }
  }
  return mask;
}

/* LE 需要随机扰动而不是几个核；用确定性噪声掩膜保证可复现 */
export function deterministicNoiseMask(seedStr, density = 0.02, w = 64, h = 64) {
  const mask = new Uint8Array(w * h);
  const rand = mulberry32(hashString(seedStr || 'le-noise'));
  for (let i = 0; i < w * h; i++) if (rand() < density) mask[i] = 255;
  return mask;
}

export function normalizeMask(input, maskW, maskH) {
  if ((!Array.isArray(input) && !ArrayBuffer.isView(input)) || !input.length) return null;
  const mw = Math.round(clamp(maskW, 8, 96, 64));
  const mh = Math.round(clamp(maskH, 8, 96, 64));
  const need = mw * mh;
  if (input.length < need) return null;
  const out = new Uint8Array(need);
  for (let i = 0; i < need; i++) {
    out[i] = Math.round(clamp(input[i], 0, 255, 0));
  }
  return { mask: out, maskW: mw, maskH: mh };
}

function round(value, digits = 4) {
  const p = 10 ** digits;
  return Math.round(value * p) / p;
}

/* 行为指纹：结构签名回答“长什么样”，行为回答“怎么动”。
 * 采样点固定，保证同一配方可复现。 */
function summarizeBehavior(samples, steps, sampleEvery) {
  if (!samples.length) return null;
  let activitySum = 0;
  let flipSum = 0;
  let pairs = 0;
  for (let i = 1; i < samples.length; i++) {
    const a = samples[i - 1].field;
    const b = samples[i].field;
    let abs = 0;
    let flips = 0;
    for (let k = 0; k < a.length; k++) {
      abs += Math.abs(b[k] - a[k]);
      if ((a[k] > 0.5) !== (b[k] > 0.5)) flips++;
    }
    activitySum += abs / a.length;
    flipSum += flips / a.length;
    pairs++;
  }
  const first = samples[0].features;
  const last = samples[samples.length - 1].features;
  let stabilizeSteps = steps;
  for (let i = 1; i < samples.length; i++) {
    const stable = samples[i].features.density > 0.01
      && signatureDistance(samples[i - 1].features, samples[i].features) < 0.03;
    if (stable) { stabilizeSteps = samples[i].step; break; }
  }
  const pattern = last.density < 0.01
    ? 'blank'
    : last.anisotropy > 0.28 ? 'stripes' : last.anisotropy < 0.12 ? 'spots' : 'mixed';
  const per100 = sampleEvery > 0 ? 100 / sampleEvery : 1;
  return {
    stabilizeSteps,
    activity: round(pairs ? (activitySum / pairs) * per100 : 0),
    flipRate: round(pairs ? (flipSum / pairs) * per100 : 0),
    growthRate: round(((last.density - first.density) / Math.max(1, steps)) * 1000, 2),
    pattern,
    samples: samples.map((s) => ({ step: s.step, ...s.features })),
  };
}

export function evaluateTarget(target, params, { w = 64, h = 64, includeField = false, includeBehavior = false } = {}) {
  const isLE = target.verify?.model === 'lengyelEpstein';
  const fixed = target.verify?.fixedMask;
  let maskInfo = null;
  if (isLE) {
    maskInfo = {
      mask: deterministicNoiseMask(
        target.verify?.fixedMaskSeed || 'le-noise',
        target.verify?.noiseDensity ?? 0.02,
        w,
        h,
      ),
      maskW: w,
      maskH: h,
    };
  } else if (fixed) {
    maskInfo = {
      mask: deterministicMask(target.verify?.fixedMaskSeed || 'calibration-seed', w, h),
      maskW: w,
      maskH: h,
    };
  } else {
    maskInfo = normalizeMask(params.mask, params.maskW, params.maskH);
  }
  const seed = maskInfo ? maskInfo.mask : deterministicMask(params.recipeId || params.name, w, h);
  const maskW = maskInfo ? maskInfo.maskW : w;
  const maskH = maskInfo ? maskInfo.maskH : h;
  const rd = new ReactionDiffusionEngine(w, h, isLE
    ? {
        preset: 'le_stripes',
        engine: 'lengyelEpstein',
        a: clamp(params.a, 5, 14, 8),
        b: clamp(params.b, 1, 8, 6),
        sigma: clamp(params.sigma, 0.2, 3, 0.6),
        D_u: clamp(params.D_u, 0.2, 3, 1),
        D_v: clamp(params.D_v, 2, 200, 80),
        dt: clamp(params.dt, 0.001, 0.05, 0.001),
        boundary: 'torus',
        pattern: 'soup',
        mask: seed,
        maskW,
        maskH,
      }
    : {
        preset: 'gs_spots',
        engine: 'grayScott',
        f: clamp(params.f, 0.005, 0.09, 0.035),
        k: clamp(params.k, 0.005, 0.09, 0.062),
        D_u: clamp(params.D_u, 0.02, 0.3, 0.16),
        D_v: clamp(params.D_v, 0.02, 0.2, 0.08),
        dt: clamp(params.dt, 0.2, 1.0, 1.0),
        boundary: 'torus',
        pattern: 'ring',
        mask: seed,
        maskW,
        maskH,
      });
  const maxSteps = isLE ? 30000 : 1200;
  const steps = Math.round(clamp(target.verify?.steps, 120, maxSteps, isLE ? 12000 : 480));
  const sampleEvery = includeBehavior ? Math.max(1, Math.floor(steps / 12)) : 0;
  const behaviorSamples = [];
  for (let i = 0; i < steps; i++) {
    rd.step();
    if (includeBehavior && ((i + 1) % sampleEvery === 0 || i === steps - 1)) {
      const sampleField = normalizeField(rd.vField);
      behaviorSamples.push({
        step: i + 1,
        field: Float32Array.from(sampleField),
        features: structuralSignature(sampleField, w, h),
      });
    }
  }
  const field = normalizeField(rd.vField);
  const features = structuralSignature(field, w, h);
  const distance = signatureDistance(target.features, features);
  const score = Math.round((100 / (1 + distance)) * 10) / 10;
  const behavior = includeBehavior ? summarizeBehavior(behaviorSamples, steps, sampleEvery) : null;
  return {
    score,
    distance: Math.round(distance * 1000) / 1000,
    features,
    steps,
    usedMask: !!maskInfo,
    usedFixedSeed: !!(fixed || isLE),
    model: isLE ? 'lengyelEpstein' : 'grayScott',
    ...(behavior ? { behavior } : {}),
    ...(includeField ? { field, w, h } : {}),
  };
}
