/* ================================================================ */
/*  众包排名 + 开放科学仓库提交                                       */
/*                                                                  */
/*  本地存储：                                                       */
/*    localStorage['commons.leaderboard.v1'] = JSON array of         */
/*      { fingerprint, params, metrics, matches, timestamp, likes } */
/*                                                                  */
/*  开放科学仓库（无后端 —— 用 GitHub Issues 作为公共看板）：          */
/*    每个发现记录可以格式化为一个 GitHub Issue 标题 + body，         */
/*    玩家复制 → 粘贴 → 提交到 commons-discoveries 仓库             */
/*    所有发现公开可见，可 star，可 issue 互动                      */
/*                                                                  */
/*  未来后端（可选）：                                               */
/*    POST /api/discoveries 上传记录                                 */
/*    GET  /api/discoveries?sort=energy 公开排名                    */
/* ================================================================ */

import { buildDiscoveryRecord } from './patterns.js';

const LB_KEY = 'commons.leaderboard.v1';
const OSR_REPO_URL = 'https://github.com/commons-org/discoveries/issues/new';

/**
 * 安全 localStorage 包装 — Node mjs / 隐私模式 / 禁用 cookie 时静默降级为内存 Map
 * 生产成熟度修复：之前 L62 clearLeaderboard 直接 localStorage.removeItem 会 throw ReferenceError
 */
let _memFallback = null;
function safeStorage() {
  try {
    if (typeof localStorage !== 'undefined' && localStorage) return localStorage;
  } catch (_) { /* 某些环境访问 localStorage 也会 throw */ }
  if (!_memFallback) _memFallback = new Map();
  return {
    getItem: (k) => _memFallback.get(k) ?? null,
    setItem: (k, v) => { _memFallback.set(k, String(v)); },
    removeItem: (k) => { _memFallback.delete(k); },
  };
}

/**
 * 读取本地 leaderboard
 */
export function loadLeaderboard() {
  try {
    const raw = safeStorage().getItem(LB_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/**
 * 保存（合并 + 去重，按 fingerprint）
 */
export function saveDiscovery(record) {
  const lb = loadLeaderboard();
  const idx = lb.findIndex(r => r.fingerprint === record.fingerprint);
  if (idx >= 0) lb[idx] = record;  // 覆盖更新
  else lb.unshift(record);         // 新的放最前
  // 最多保留 200 条
  while (lb.length > 200) lb.pop();
  try { safeStorage().setItem(LB_KEY, JSON.stringify(lb)); } catch { /* 静默失败 */ }
  return lb;
}

/**
 * 删除一条
 */
export function deleteDiscovery(fingerprint) {
  const lb = loadLeaderboard().filter(r => r.fingerprint !== fingerprint);
  try { safeStorage().setItem(LB_KEY, JSON.stringify(lb)); } catch { /* 静默失败 */ }
  return lb;
}

/**
 * 清空
 */
export function clearLeaderboard() {
  try { safeStorage().removeItem(LB_KEY); } catch { /* 静默失败 */ }
}

/**
 * 排序 leaderboard
 * sortBy: 'similarity' | 'energy' | 'fractal' | 'lyapunov' | 'recent'
 * 返回排序后的新数组（不修改原 leaderboard）
 */
export function rankDiscoveries(lb, sortBy = 'similarity') {
  const items = [...lb];
  switch (sortBy) {
    case 'energy':
      items.sort((a, b) => (a.metrics?.energy?.total ?? Infinity) - (b.metrics?.energy?.total ?? Infinity));
      break;
    case 'fractal':
      items.sort((a, b) => (b.metrics?.fractal ?? 0) - (a.metrics?.fractal ?? 0));
      break;
    case 'lyapunov':
      items.sort((a, b) => (b.metrics?.lyapunov ?? 0) - (a.metrics?.lyapunov ?? 0));
      break;
    case 'similarity':
      items.sort((a, b) => {
        const sa = a.patternMatches?.[0]?.similarity ?? 0;
        const sb = b.patternMatches?.[0]?.similarity ?? 0;
        return sb - sa;
      });
      break;
    case 'recent':
    default:
      items.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  }
  return items;
}

/**
 * 用 recipe + metrics + patternMatches 一键保存到 leaderboard
 * 返回保存后的 leaderboard 条目（含 fingerprint）
 */
export function saveAsDiscovery(recipe, metrics, topMatches) {
  const record = buildDiscoveryRecord(recipe, metrics, topMatches);
  saveDiscovery(record);
  return record;
}

/**
 * 导入 JSON 字符串到 leaderboard（支持单条或数组）
 */
export function importDiscoveries(jsonStr) {
  let data;
  try { data = JSON.parse(jsonStr); } catch { return { ok: false, error: 'JSON 解析失败' }; }
  if (!Array.isArray(data)) data = [data];
  const lb = loadLeaderboard();
  let added = 0, updated = 0;
  for (const r of data) {
    if (!r.fingerprint) continue;
    const idx = lb.findIndex(x => x.fingerprint === r.fingerprint);
    if (idx >= 0) { lb[idx] = r; updated++; }
    else { lb.unshift(r); added++; }
  }
  try { safeStorage().setItem(LB_KEY, JSON.stringify(lb)); } catch { /* 静默失败 */ }
  return { ok: true, added, updated, total: lb.length };
}

/**
 * 导出 leaderboard 为 JSON 字符串（可粘贴到 GitHub issue）
 */
export function exportLeaderboard(lb) {
  return JSON.stringify(lb, null, 2);
}

/**
 * 生成 GitHub issue body（开放科学仓库提交用）
 * 返回 { url, title, body }
 * 玩家在 UI 点"提交到开放科学" → 复制 body → 打开 url → 粘贴 → 提交
 */
export function buildOpenScienceIssue(record, opts = {}) {
  const matched = record.patternMatches?.[0];
  const similarity = matched ? matched.similarity + '%' : 'N/A';
  const attrLabel = record.metrics?.attrLabel ?? '未知';

  const title = `[发现] ${record.engine} · ${attrLabel} · 相似度 ${similarity}`;

  const body = `## 我的发现

| 项目 | 值 |
|------|-----|
| **指纹** | \`${record.fingerprint}\` |
| **引擎** | ${record.engine} |
| **吸引子类型** | ${attrLabel} |
| **时间** | ${record.timestamp} |

### 科学指标

| 指标 | 值 | 范围 |
|------|-----|------|
| λ_FT（有限时间 Lyapunov，估计） | ${record.metrics?.lyapunov?.toFixed(4) ?? '—'} | -0.3 ~ +0.3 |
| D_box（盒计数维数，估计） | ${record.metrics?.fractal?.toFixed(3) ?? '—'} | 1.0 ~ 2.0 |
| H_v（场熵） | ${record.metrics?.entropy?.toFixed(3) ?? '—'} | 0 ~ 1 |
| L_c（相关长度） | ${record.metrics?.period ?? '—'} 格 | |
| E_field（场能量估计） | ${record.metrics?.energy?.total?.toFixed(4) ?? '—'} | 0.2 ~ 8.0 |
| 密度 | ${((record.metrics?.density ?? 0) * 100).toFixed(1)}% | |

> 注：λ_FT 是有限时间 tangent-space 估计，不宣称收敛的渐近 Lyapunov 指数；D_box / H_v / L_c / E_field 也均为本工具内的诊断量，用于相对比较。

### 已发表模式匹配

${(record.patternMatches || []).map((m, i) =>
  `${i + 1}. **${m.label}** — 相似度 ${m.similarity}%  \n   > ${m.engine}`
).join('\n\n') || '_无匹配_'}

### 科学参数

\`\`\`json
${JSON.stringify(record.params, null, 2)}
\`\`\`

### 假设（可选）

${opts.hypothesis || '_我觉得这种形态可能是因为..._'}

---
*提交自 Commons v2.0 反应-扩散引擎 · 开放科学模式*
`;

  // 构造 GitHub issue URL（预填 title + body，玩家仍需手动粘贴）
  const url = `${OSR_REPO_URL}?title=${encodeURIComponent(title)}`;

  return { url, title, body };
}
