// Visual layer: one visual grammar, procedurally rendered from life state.
// Colour / form / opacity / boundary / event signatures are defined once and reused.

import { clamp } from './rng.js';

const TINTS = {
  a: {
    bg: [5, 8, 12],
    hue: 156,
    hue2: 190,
    accent: '#7cffb2',
    accent2: '#57d8ff',
    body: [126, 255, 178],
  },
  b: {
    bg: [11, 7, 12],
    hue: 36,
    hue2: 332,
    accent: '#ffc46b',
    accent2: '#c39bff',
    body: [255, 196, 107],
  },
};

const LENIA_RAMP_A = [
  [10, 18, 40],
  [18, 78, 92],
  [43, 196, 168],
  [150, 255, 176],
  [240, 255, 236],
];
const LENIA_RAMP_B = [
  [26, 10, 30],
  [92, 30, 82],
  [206, 70, 120],
  [255, 186, 92],
  [255, 244, 220],
];

function rampColor(ramp, t) {
  const x = clamp(t, 0, 1) * (ramp.length - 1);
  const i = Math.floor(x);
  const f = x - i;
  const a = ramp[Math.min(i, ramp.length - 1)];
  const b = ramp[Math.min(i + 1, ramp.length - 1)];
  return [
    Math.round(a[0] + (b[0] - a[0]) * f),
    Math.round(a[1] + (b[1] - a[1]) * f),
    Math.round(a[2] + (b[2] - a[2]) * f),
  ];
}

const AGE_BUCKETS = [
  { max: 0, l: 86, s: 82, a: 1 },
  { max: 1, l: 74, s: 92, a: 0.96 },
  { max: 2, l: 64, s: 88, a: 0.9 },
  { max: 4, l: 54, s: 82, a: 0.82 },
  { max: 9, l: 44, s: 74, a: 0.7 },
  { max: 19, l: 35, s: 66, a: 0.56 },
  { max: Infinity, l: 27, s: 58, a: 0.4 },
];

function ageBucket(age, activity) {
  let idx = 0;
  for (let i = 0; i < AGE_BUCKETS.length; i++) {
    if (age <= AGE_BUCKETS[i].max) {
      idx = i;
      break;
    }
  }
  const b = AGE_BUCKETS[idx];
  return {
    l: clamp(b.l + (activity > 0.5 ? 5 : 0), 0, 100),
    s: b.s,
    a: b.a,
  };
}

export class StageRenderer {
  constructor(canvas, opts = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.tintKey = opts.tint || 'a';
    this.sim = null;
    this.metrics = null;
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.lastW = 0;
    this.lastH = 0;
    this.offscreen = document.createElement('canvas');
    this.offctx = this.offscreen.getContext('2d');
    this.imgData = null;
    this.pulse = null;
    this.flash = 0;
    this.scan = 0;
    this.compact = !!opts.compact;
    this._bound = false;
  }

  get tint() {
    return TINTS[this.tintKey] || TINTS.a;
  }

  setTint(key) {
    this.tintKey = key;
  }

  attach(sim) {
    this.sim = sim;
    this.imgData = null;
    this.offscreen.width = sim.w;
    this.offscreen.height = sim.h;
    this.imgData = this.offctx.createImageData(sim.w, sim.h);
    this.clear();
  }

  setMetrics(m) {
    this.metrics = m;
  }

  triggerPulse(type, strength = 1) {
    this.pulse = { type, t0: performance.now(), strength };
    this.flash = Math.min(1, this.flash + 0.6 * strength);
  }

  clear() {
    const { ctx, canvas } = this;
    const t = this.tint;
    ctx.fillStyle = `rgb(${t.bg[0]},${t.bg[1]},${t.bg[2]})`;
    ctx.fillRect(0, 0, canvas.width || 1, canvas.height || 1);
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const w = Math.max(1, Math.round(rect.width * this.dpr));
    const h = Math.max(1, Math.round(rect.height * this.dpr));
    if (w !== this.canvas.width || h !== this.canvas.height) {
      this.canvas.width = w;
      this.canvas.height = h;
      this.clear();
    }
    this.cssW = rect.width;
    this.cssH = rect.height;
  }

  draw(now) {
    if (!this.sim) return;
    this.resize();
    const { ctx, canvas, sim } = this;
    const t = this.tint;
    const W = canvas.width;
    const H = canvas.height;
    const m = this.metrics;
    const activity = m ? clamp(m.activity, 0, 1) : 0.2;

    // trail fade — the organism leaves an afterimage
    const fade = sim.kind === 'lenia' ? 0.16 : 0.3;
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = `rgba(${t.bg[0]},${t.bg[1]},${t.bg[2]},${fade})`;
    ctx.fillRect(0, 0, W, H);

    const scale = Math.min(W / sim.w, H / sim.h);
    const ox = (W - sim.w * scale) / 2;
    const oy = (H - sim.h * scale) / 2;

    if (sim.kind === 'lenia') this._drawLenia(scale, ox, oy, activity);
    else this._drawLife(scale, ox, oy, activity);

    // subtle rule grid
    if (!this.compact) this._drawGrid(scale, ox, oy, W, H);

    // event signature + scanline
    this._drawPulse(now, W, H);
    if (!this.compact) this._drawScan(now, W, H);
    this.flash *= 0.9;
  }

  _drawLife(scale, ox, oy, activity) {
    const { ctx, sim } = this;
    const t = this.tint;
    const w = sim.w;
    const h = sim.h;
    const { grid, age } = sim;
    const cell = scale;
    const gap = Math.max(0.5, cell * 0.2);
    const buckets = AGE_BUCKETS.map(() => [[], []]);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        if (!grid[i]) continue;
        let b = 0;
        for (let k = 0; k < AGE_BUCKETS.length; k++) {
          if (age[i] <= AGE_BUCKETS[k].max) {
            b = k;
            break;
          }
        }
        buckets[b][(x + y) & 1].push(x, y);
      }
    }

    // glow pass — soft bioluminescence, strongest on newborns
    ctx.globalCompositeOperation = 'lighter';
    for (let b = 0; b < buckets.length; b++) {
      if (b >= 5) continue;
      const info = ageBucket(b === 0 ? 0 : b === 1 ? 1 : b === 2 ? 2 : b < 5 ? 4 : b < 6 ? 9 : 20, activity);
      const glow = b === 0 ? 0.2 : 0.05;
      const gs = cell * (b === 0 ? 2.7 : 1.9);
      const off = (gs - cell) / 2;
      for (let p = 0; p < 2; p++) {
        const arr = buckets[b][p];
        if (!arr.length) continue;
        ctx.fillStyle = `hsla(${t.hue + b * 4 - p * 7}, ${info.s}%, ${Math.min(76, info.l + 6)}%, ${glow})`;
        for (let k = 0; k < arr.length; k += 2) {
          ctx.fillRect(ox + arr[k] * cell - off, oy + arr[k + 1] * cell - off, gs, gs);
        }
      }
    }

    // body pass — two micro-hue variants keep it organic
    ctx.globalCompositeOperation = 'source-over';
    const hueShift = activity * 8;
    for (let b = 0; b < buckets.length; b++) {
      const info = ageBucket(b === 0 ? 0 : b === 1 ? 1 : b === 2 ? 2 : b < 5 ? 4 : b < 6 ? 9 : 20, activity);
      const size = cell - gap;
      for (let p = 0; p < 2; p++) {
        const arr = buckets[b][p];
        if (!arr.length) continue;
        const hue = (b === 0 ? t.hue + 4 : t.hue + b * 4 + hueShift) + (p ? 4 : -3);
        ctx.fillStyle = `hsla(${hue}, ${info.s}%, ${info.l}%, ${info.a})`;
        for (let k = 0; k < arr.length; k += 2) {
          ctx.fillRect(ox + arr[k] * cell + gap / 2, oy + arr[k + 1] * cell + gap / 2, size, size);
        }
      }
    }

    // newborn sparkle
    ctx.globalCompositeOperation = 'lighter';
    const newborns = buckets[0];
    ctx.fillStyle = `rgba(240,255,248,${0.28 + activity * 0.22})`;
    const s = Math.max(1, cell * 0.5);
    for (let p = 0; p < 2; p++) {
      const arr = newborns[p];
      for (let k = 0; k < arr.length; k += 2) {
        ctx.fillRect(ox + arr[k] * cell + (cell - s) / 2, oy + arr[k + 1] * cell + (cell - s) / 2, s, s);
      }
    }
    ctx.globalCompositeOperation = 'source-over';
  }

  _drawLenia(scale, ox, oy, activity) {
    const { ctx, sim, offscreen, offctx } = this;
    const t = this.tint;
    const w = sim.w;
    const h = sim.h;
    if (!this.imgData || this.imgData.width !== w) {
      this.imgData = offctx.createImageData(w, h);
    }
    const data = this.imgData.data;
    const ramp = this.tintKey === 'b' ? LENIA_RAMP_B : LENIA_RAMP_A;
    const boost = 0.82 + activity * 0.3;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = y * w + x;
        const v = sim.field[i];
        const left = sim.field[y * w + ((x - 1 + w) % w)];
        const up = sim.field[((y - 1 + h) % h) * w + x];
        const edge = clamp(Math.abs(v - left) + Math.abs(v - up), 0, 1);
        const c = rampColor(ramp, Math.pow(clamp(v * boost, 0, 1), 0.84));
        const e = edge * 0.42;
        const p = i * 4;
        data[p] = Math.min(255, c[0] + e * 130);
        data[p + 1] = Math.min(255, c[1] + e * 130);
        data[p + 2] = Math.min(255, c[2] + e * 130);
        data[p + 3] = v < 0.035 ? 0 : Math.min(255, 36 + v * 250 + edge * 90);
      }
    }
    offctx.putImageData(this.imgData, 0, 0);
    ctx.globalCompositeOperation = 'lighter';
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(offscreen, ox, oy, w * scale, h * scale);
    ctx.globalCompositeOperation = 'source-over';
    // faint crisp pass keeps structure legible
    ctx.globalAlpha = 0.35;
    ctx.drawImage(offscreen, ox, oy, w * scale, h * scale);
    ctx.globalAlpha = 1;
    void t;
  }

  _drawGrid(scale, ox, oy, W, H) {
    const { ctx, sim } = this;
    ctx.strokeStyle = 'rgba(255,255,255,0.028)';
    ctx.lineWidth = 1;
    const step = Math.max(8, Math.round(sim.w / 15) * scale);
    ctx.beginPath();
    for (let x = ox; x <= ox + sim.w * scale; x += step) {
      ctx.moveTo(x, oy);
      ctx.lineTo(x, oy + sim.h * scale);
    }
    for (let y = oy; y <= oy + sim.h * scale; y += step) {
      ctx.moveTo(ox, y);
      ctx.lineTo(ox + sim.w * scale, y);
    }
    ctx.stroke();
    void W;
    void H;
  }

  _drawPulse(now, W, H) {
    if (!this.pulse) return;
    const p = this.pulse;
    const elapsed = (now - p.t0) / 1000;
    if (elapsed > 2.4) {
      this.pulse = null;
      return;
    }
    const t = this.tint;
    const cx = W / 2;
    const cy = H / 2;
    const base = Math.min(W, H);
    const ctx = this.ctx;
    ctx.save();
    if (p.type === 'chaotic') {
      const n = 9;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 + now * 0.001;
        const r = base * (0.18 + ((elapsed * 0.8 + i * 0.09) % 1) * 0.3);
        ctx.strokeStyle = `hsla(${t.hue2 + i * 6}, 90%, 68%, ${0.22 * (1 - elapsed / 2.4)})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(cx, cy, r, a, a + 0.9);
        ctx.stroke();
      }
    } else if (p.type === 'endangered' || p.type === 'extinct') {
      const alpha = 0.4 * (1 - elapsed / 2.4);
      ctx.fillStyle = `hsla(20, 82%, 55%, ${alpha * 0.1})`;
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = `hsla(20, 82%, 62%, ${alpha})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, base * (0.22 + Math.sin(elapsed * 3) * 0.01), 0, Math.PI * 2);
      ctx.stroke();
    } else if (p.type === 'reproduction') {
      for (let i = 0; i < 2; i++) {
        const r = base * (0.1 + ((elapsed + i * 0.35) % 1) * 0.42);
        ctx.strokeStyle = `hsla(${t.hue}, 92%, 68%, ${0.5 * (1 - ((elapsed + i * 0.35) % 1))})`;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else {
      const r = base * (0.1 + Math.min(1, elapsed / 1.8) * 0.45);
      const alpha = Math.max(0, 0.5 * (1 - elapsed / 2.2));
      ctx.strokeStyle = `hsla(${t.hue}, 92%, 70%, ${alpha})`;
      ctx.lineWidth = p.type === 'stable' ? 1.4 : 2.2;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
      if (p.type === 'periodic') {
        ctx.strokeStyle = `hsla(${t.hue2}, 90%, 70%, ${alpha * 0.6})`;
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.72, Math.PI * 0.1, Math.PI * 1.1);
        ctx.stroke();
      }
    }
    ctx.restore();
  }

  _drawScan(now, W, H) {
    const ctx = this.ctx;
    const y = ((now * 0.02) % (H + 120)) - 60;
    const grad = ctx.createLinearGradient(0, y - 40, 0, y + 40);
    grad.addColorStop(0, 'rgba(255,255,255,0)');
    grad.addColorStop(0.5, `rgba(255,255,255,${0.022 + this.flash * 0.04})`);
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, y - 40, W, 80);
  }
}

/* ------------------------------------------------------------------ */
/* Shared procedural assets                                            */
/* ------------------------------------------------------------------ */

export function drawSnapshot(canvas, snapshot, tintKey = 'a', opts = {}) {
  if (!canvas || !snapshot) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const rect = canvas.getBoundingClientRect();
  const W = Math.max(1, Math.round((rect.width || opts.w || 240) * dpr));
  const H = Math.max(1, Math.round((rect.height || opts.h || 135) * dpr));
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');
  const t = TINTS[tintKey] || TINTS.a;
  ctx.fillStyle = `rgb(${t.bg[0]},${t.bg[1]},${t.bg[2]})`;
  ctx.fillRect(0, 0, W, H);

  const { data, w, h } = snapshot;
  // crop to the organism's bounding box so sparse seeds still read as alive
  let minX = w;
  let minY = h;
  let maxX = -1;
  let maxY = -1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (!data[y * w + x]) continue;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
  }
  if (maxX < 0) {
    // extinct / dormant seed: keep a quiet specimen mark instead of an empty card
    const c = Math.min(W, H) * 0.22;
    ctx.strokeStyle = `hsla(${t.hue}, 70%, 55%, 0.35)`;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, c, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = `hsla(${t.hue}, 80%, 60%, 0.5)`;
    ctx.beginPath();
    ctx.arc(W / 2, H / 2, Math.max(2, c * 0.1), 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  const bw = maxX - minX + 1;
  const bh = maxY - minY + 1;
  const scale = Math.min((W * 0.9) / bw, (H * 0.9) / bh);
  const ox = (W - bw * scale) / 2 - minX * scale;
  const oy = (H - bh * scale) / 2 - minY * scale;
  const cell = Math.max(1, scale);
  // faint structural field
  ctx.globalCompositeOperation = 'lighter';
  ctx.fillStyle = `hsla(${t.hue}, 82%, 58%, 0.14)`;
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (!data[y * w + x]) continue;
      ctx.fillRect(ox + x * cell - cell, oy + y * cell - cell, cell * 3.2, cell * 3.2);
    }
  }
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (!data[y * w + x]) continue;
      const jitter = ((x * 13 + y * 7) % 5) / 40;
      ctx.fillStyle = `hsla(${t.hue + jitter * 40}, 88%, ${58 + jitter * 28}%, 0.92)`;
      ctx.fillRect(ox + x * cell, oy + y * cell, Math.max(1, cell * 0.9), Math.max(1, cell * 0.9));
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.14, W / 2, H / 2, H * 0.95);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.42)');
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
}

export function drawFingerprintGlyph(canvas, metrics, tintKey = 'a') {
  if (!canvas || !metrics) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const rect = canvas.getBoundingClientRect();
  const size = Math.max(40, Math.round((rect.width || 88) * dpr));
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const t = TINTS[tintKey] || TINTS.a;
  ctx.clearRect(0, 0, size, size);
  const c = size / 2;
  const accent = t.accent;
  ctx.save();
  ctx.translate(c, c);
  const rings = 3 + (metrics.period % 4);
  const arcCount = 4 + (metrics.components % 7);
  for (let r = 0; r < rings; r++) {
    const radius = size * (0.16 + r * 0.1);
    ctx.strokeStyle = accent;
    ctx.globalAlpha = 0.16 + (r / rings) * 0.3;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.stroke();
    const segs = arcCount;
    for (let s = 0; s < segs; s++) {
      if ((s + r + metrics.components) % 3 === 0) continue;
      const a0 = (s / segs) * Math.PI * 2 + metrics.entropy * 2 + r * 0.4;
      const span = (Math.PI * 2) / segs * (0.2 + metrics.stability * 0.5);
      ctx.globalAlpha = 0.25 + metrics.density * 0.5;
      ctx.beginPath();
      ctx.arc(0, 0, radius, a0, a0 + span);
      ctx.stroke();
    }
  }
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = accent;
  const dots = 3 + Math.round(metrics.density * 8);
  for (let i = 0; i < dots; i++) {
    const a = (i / dots) * Math.PI * 2 + metrics.entropy * 6;
    const rr = size * (0.08 + ((i * 7 + metrics.period) % 5) * 0.012);
    ctx.beginPath();
    ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr, Math.max(1, size * 0.008), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawSparkline(canvas, values, tintKey = 'a', opts = {}) {
  if (!canvas) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const rect = canvas.getBoundingClientRect();
  const W = Math.max(1, Math.round((rect.width || 120) * dpr));
  const H = Math.max(1, Math.round((rect.height || 34) * dpr));
  if (canvas.width !== W || canvas.height !== H) {
    canvas.width = W;
    canvas.height = H;
  }
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, W, H);
  const t = TINTS[tintKey] || TINTS.a;
  if (!values.length) return;
  const min = opts.min ?? Math.min(...values);
  const max = opts.max ?? Math.max(...values);
  const span = max - min || 1;
  ctx.beginPath();
  values.forEach((v, i) => {
    const x = (i / Math.max(1, values.length - 1)) * W;
    const y = H - 2 - ((v - min) / span) * (H - 4);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = t.accent;
  ctx.globalAlpha = 0.85;
  ctx.lineWidth = Math.max(1, dpr);
  ctx.stroke();
  const last = values[values.length - 1];
  const lx = W;
  const ly = H - 2 - ((last - min) / span) * (H - 4);
  ctx.globalAlpha = 1;
  ctx.fillStyle = t.accent;
  ctx.beginPath();
  ctx.arc(Math.min(W - 2, lx), ly, 2 * dpr, 0, Math.PI * 2);
  ctx.fill();
}

export function paletteFor(key) {
  return TINTS[key] || TINTS.a;
}
